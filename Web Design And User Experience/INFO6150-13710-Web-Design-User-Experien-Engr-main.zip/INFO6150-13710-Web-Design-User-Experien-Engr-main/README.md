# Group Project INFO6150: 13710 Web Design/User Experience Engr <br>
## Team: 4 <br>
Apoorva Kethamaranahalli : kethamaranahalli.a@northeastern.edu <br>
Nishanth Reddy Kogilathota : kogilathota.n@northeastern.edu <br>
Niveditha Bharadwaj : bharadwaj.ni@northeastern.edu <br>
Sharan Chandra Shekar : chandrashekar.sh@northeastern.edu <br>
Swaroop Gupta B A : byrandurgaaswathan.s@northeastern.edu <br>
